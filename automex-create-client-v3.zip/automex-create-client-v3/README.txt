Automex Create Client — small v3 update

Replace:
  src/pages/CreateLead.jsx
  src/styles.css

Changes:
- Budget labels dynamically display the approximate regional currency and tier amounts from the selected phone country.
- Selecting a different phone country clears the budget selection so visitors can confirm the new currency.
- A 10px visual gap now separates the country-code select from the national number field.
- POST still sends phone as E.164 (e.g. +919876543210, no visual spaces) and retains the existing budget enum strings.
- Existing backend API endpoints are unchanged.

Currency tiers are indicative, not live exchange rates. If precise exchange-rate equivalence matters to your business, use server-provided currency pricing.
